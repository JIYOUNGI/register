package egovframework.example.sample.service;

public interface MemberService {
	
//	회원등록처리
	
	public String insertMember(MemberVO vo) throws Exception;
          //return값
	
	//중복아이디 체크
	
	public int selectMemberIdCheck(String userid) throws Exception;
	
	//로그인 데이터 확인
	public int selectMemberCount(MemberVO vo) throws Exception;
}
