package egovframework.example.sample.service.impl;

import org.springframework.stereotype.Repository;

import egovframework.example.sample.service.MemberVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("memberDAO")
public class MemberDAO extends EgovAbstractDAO {

	public String insertMember(MemberVO vo) {
		// TODO Auto-generated method stub
		return (String)insert("memberDAO.insertMember",vo);
		      //mybatis와 연결하기 위해 사용
	}

	public int selectMemberIdCheck(String userid) {
		// TODO Auto-generated method stub
		return (int)select("memberDAO.selectMemberIdCheck",userid);
	}

	public int selectMemberCount(MemberVO vo) {
		// TODO Auto-generated method stub
		return (int)select("memberDAO.selectMemberCount",vo);
	}



}
