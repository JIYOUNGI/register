package egovframework.web;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import egovframework.example.sample.service.MemberService;
import egovframework.example.sample.service.MemberVO;

@Controller
public class MemberController {
	
	//resource작업을 해야 서비스 작업을 할 수 있음
	@Resource(name="memberService")
	public MemberService memberService;
	
	@RequestMapping("/memberWrite.do")
	public String memberWrite() {
		
		
		return "memberWrite";
	}
	
	@RequestMapping("/memberWriteSave.do")
	@ResponseBody
	//responsebody를 작성해서 메시지가 전달될수 있도록 해야함
	public String insertMember(MemberVO vo) throws Exception {
		
		String message ="";
		String result = memberService.insertMember(vo);
		
		if(result == null) {
			message = "ok";
		}
		
		
		return message;
	}
	
	@RequestMapping("/idcheck.do")
	@ResponseBody
	public String selectMemberIdCheck(String userid) throws Exception {//id값이 전달되고 있는 상황
		
		String message = "";
		
		int count = memberService.selectMemberIdCheck(userid);
		if( count == 0 ) {
			message = "ok";
		}
		
		return message;
	}
	
	@RequestMapping("/loginWrite.do")
	public String loginWrite() {
		
		
		return "loginWrite";
	}
	
	@RequestMapping("/loginWriteSub.do")
	@ResponseBody
	public String loginProcessing(MemberVO vo,HttpSession session) throws Exception {
		String message = "";
		
		int count = memberService.selectMemberCount(vo);
		if( count == 1 ) {
			//session 생성
			session.setAttribute("SessionUserID",vo.getUserid());//userid는 vo에 들어가있음
			//message 처리
			message = "ok";
		}	
		
		
		return message;
	}
	
	@RequestMapping("/logout.do")
	public String logout(HttpSession session) {//세션지울때도 httpsession 필요하징
		
		session.removeAttribute("SessionUserID");
		
		return "loginWrite";
	}

}

























